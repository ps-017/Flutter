# Calculator App

Simple calculator with add, subtract, multiply and divide.

## How to run

1. Open this folder in VS Code or Android Studio
2. Run `flutter pub get`
3. Connect a phone / start emulator (or use Chrome)
4. Run `flutter run`

Code is inside the `lib` folder.
