import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Calculator',
      debugShowCheckedModeBanner: false,
      home: Calculator(),
    );
  }
}

class Calculator extends StatefulWidget {
  const Calculator({super.key});

  @override
  State<Calculator> createState() => _CalculatorState();
}

class _CalculatorState extends State<Calculator> {
  String display = '0';
  double num1 = 0;
  String operator = '';
  bool newNumber = true;

  void buttonPressed(String text) {
    setState(() {
      if (text == 'C') {
        display = '0';
        num1 = 0;
        operator = '';
        newNumber = true;
      } else if (text == '+' || text == '-' || text == 'x' || text == '/') {
        num1 = double.tryParse(display) ?? 0;
        operator = text;
        newNumber = true;
      } else if (text == '=') {
        if (operator.isEmpty) return;
        double num2 = double.tryParse(display) ?? 0;
        double result = 0;

        if (operator == '+') {
          result = num1 + num2;
        } else if (operator == '-') {
          result = num1 - num2;
        } else if (operator == 'x') {
          result = num1 * num2;
        } else if (operator == '/') {
          if (num2 == 0) {
            display = 'Error';
            operator = '';
            newNumber = true;
            return;
          }
          result = num1 / num2;
        }

        display = formatResult(result);
        operator = '';
        newNumber = true;
      } else if (text == '.') {
        if (newNumber) {
          display = '0.';
          newNumber = false;
        } else if (!display.contains('.')) {
          display += '.';
        }
      } else {
        // number buttons
        if (newNumber || display == '0') {
          display = text;
          newNumber = false;
        } else {
          display += text;
        }
      }
    });
  }

  // remove .0 from whole numbers
  String formatResult(double value) {
    if (value == value.toInt()) {
      return value.toInt().toString();
    }
    return value.toStringAsFixed(4).replaceAll(RegExp(r'0+$'), '');
  }

  Widget buildButton(String text, Color color) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(6),
        child: ElevatedButton(
          onPressed: () => buttonPressed(text),
          style: ElevatedButton.styleFrom(
            backgroundColor: color,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 22),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          child: Text(text, style: const TextStyle(fontSize: 24)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculator'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          Expanded(
            child: Container(
              alignment: Alignment.bottomRight,
              padding: const EdgeInsets.all(20),
              child: Text(
                display,
                style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          const Divider(),
          Row(children: [
            buildButton('7', Colors.grey),
            buildButton('8', Colors.grey),
            buildButton('9', Colors.grey),
            buildButton('/', Colors.orange),
          ]),
          Row(children: [
            buildButton('4', Colors.grey),
            buildButton('5', Colors.grey),
            buildButton('6', Colors.grey),
            buildButton('x', Colors.orange),
          ]),
          Row(children: [
            buildButton('1', Colors.grey),
            buildButton('2', Colors.grey),
            buildButton('3', Colors.grey),
            buildButton('-', Colors.orange),
          ]),
          Row(children: [
            buildButton('.', Colors.grey),
            buildButton('0', Colors.grey),
            buildButton('C', Colors.red),
            buildButton('+', Colors.orange),
          ]),
          Row(children: [
            buildButton('=', Colors.teal),
          ]),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}
