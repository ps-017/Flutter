import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BMI Calculator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
      ),
      home: const BmiPage(),
    );
  }
}

class BmiPage extends StatefulWidget {
  const BmiPage({super.key});

  @override
  State<BmiPage> createState() => _BmiPageState();
}

class _BmiPageState extends State<BmiPage> {
  final heightController = TextEditingController();
  final weightController = TextEditingController();

  double? bmi;
  String category = '';
  Color resultColor = Colors.black;

  void calculateBmi() {
    double? height = double.tryParse(heightController.text);
    double? weight = double.tryParse(weightController.text);

    if (height == null || weight == null || height <= 0 || weight <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter valid height and weight')),
      );
      return;
    }

    // height is in cm, convert to meter
    double h = height / 100;
    double result = weight / (h * h);

    setState(() {
      bmi = result;
      if (result < 18.5) {
        category = 'Underweight';
        resultColor = Colors.orange;
      } else if (result < 25) {
        category = 'Normal';
        resultColor = Colors.green;
      } else if (result < 30) {
        category = 'Overweight';
        resultColor = Colors.deepOrange;
      } else {
        category = 'Obese';
        resultColor = Colors.red;
      }
    });
  }

  void reset() {
    setState(() {
      heightController.clear();
      weightController.clear();
      bmi = null;
      category = '';
    });
  }

  @override
  void dispose() {
    heightController.dispose();
    weightController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BMI Calculator'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: heightController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Height (cm)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 15),
            TextField(
              controller: weightController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Weight (kg)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: calculateBmi,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                    ),
                    child: const Text('Calculate'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton(
                    onPressed: reset,
                    child: const Text('Reset'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 40),
            if (bmi != null) ...[
              const Text('Your BMI is', style: TextStyle(fontSize: 18)),
              Text(
                bmi!.toStringAsFixed(1),
                style: const TextStyle(fontSize: 50, fontWeight: FontWeight.bold),
              ),
              Text(
                category,
                style: TextStyle(fontSize: 24, color: resultColor),
              ),
            ],
            const SizedBox(height: 40),
            const Text(
              'Underweight: below 18.5\n'
              'Normal: 18.5 - 24.9\n'
              'Overweight: 25 - 29.9\n'
              'Obese: 30 and above',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
