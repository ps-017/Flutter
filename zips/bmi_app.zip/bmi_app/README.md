# BMI Calculator

Enter height (cm) and weight (kg) to get BMI and category.

## How to run

1. Open this folder in VS Code or Android Studio
2. Run `flutter pub get`
3. Connect a phone / start emulator (or use Chrome)
4. Run `flutter run`

Code is inside the `lib` folder.
